//
//  SWSettingViewController.h
//  LEDControl
//
//  Created by Chad Berkley on 8/21/14.
//  Copyright (c) 2014 Chad Berkley. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SWLEDController.h"
#import "SWFireController.h"

@interface SWSettingViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *ipAddressTextField;

@end
