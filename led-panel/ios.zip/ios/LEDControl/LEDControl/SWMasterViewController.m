//
//  SWMasterViewController.m
//  LEDControl
//
//  Created by Chad Berkley on 7/23/14.
//  Copyright (c) 2014 Chad Berkley. All rights reserved.
//

#import "SWMasterViewController.h"

@interface SWMasterViewController () {
}
@end

@implementation SWMasterViewController

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
