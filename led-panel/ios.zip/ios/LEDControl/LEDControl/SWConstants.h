//
//  SWConstants.h
//  LEDControl
//
//  Created by Chad Berkley on 8/21/14.
//  Copyright (c) 2014 Chad Berkley. All rights reserved.
//

#define IP_ADDRESS @"IP_ADDRESS"

