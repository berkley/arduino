//
//  SWBasicFireViewController.h
//  LEDControl
//
//  Created by Chad Berkley on 7/26/14.
//  Copyright (c) 2014 Chad Berkley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SWBasicFireViewController : UIViewController
{

}

@property (weak, nonatomic) IBOutlet UIButton *randomPuffsButton;

@end
