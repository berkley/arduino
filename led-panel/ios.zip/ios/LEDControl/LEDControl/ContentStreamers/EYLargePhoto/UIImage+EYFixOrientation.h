//
//  UIImage+EYFixOrientation.h
//  ELCImagePickerDemo
//
//  Created by ericyang on 14-4-25.
//  Copyright (c) 2014年 ELC Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (EYFixOrientation)
- (UIImage *)fixOrientation;
@end
